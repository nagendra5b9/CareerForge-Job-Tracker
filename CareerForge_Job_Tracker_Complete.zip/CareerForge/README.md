# CareerForge — Job Command Center

CareerForge is a Java/Spring Boot + PostgreSQL full-stack job application tracker designed as a portfolio project for a Java Full Stack Developer.

## Features
- Dashboard with pipeline metrics and response rate
- Application CRUD with status pipeline
- Search and filtering
- Job discovery adapter endpoint
- Match score tracking
- Resume/source/work-mode metadata
- Next-action and deadline fields
- Analytics funnel
- Provider integration registry
- Sync-event ingestion for approved connectors
- PostgreSQL persistence
- Actuator health endpoint
- Responsive UI
- GitHub Actions CI

## Important integration design
CareerForge does **not** store Naukri/LinkedIn/Indeed passwords or pretend to have unrestricted access to protected application data. Real automatic synchronization should be implemented through an officially approved OAuth/API integration, partner feed, webhook, email parser, CSV/JSON import, or browser-extension event bridge where permitted by the provider.

The `/api/sync/{provider}/event` endpoint is the normalized event boundary for those connectors.

## Run locally
1. Create PostgreSQL database `careerforge_db`.
2. Set `DB_USERNAME` and `DB_PASSWORD` or edit `application.properties`.
3. Run `mvn spring-boot:run`.
4. Open `http://localhost:8080`.

## Production
Use environment variables for DB credentials. Do not commit secrets. For a production deployment, put the app behind HTTPS and add authentication/authorization before exposing personal job data.
