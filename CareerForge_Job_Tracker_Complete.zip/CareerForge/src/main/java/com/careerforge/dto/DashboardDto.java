package com.careerforge.dto;
public record DashboardDto(long total,long saved,long applied,long screening,long assessment,long interview,long offers,long rejected,long responseRate,int avgMatchScore) {}
