package com.careerforge.controller;
import com.careerforge.dto.DashboardDto; import com.careerforge.model.*; import com.careerforge.service.JobApplicationService; import jakarta.validation.Valid; import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/applications")
public class ApplicationController {
 private final JobApplicationService service; public ApplicationController(JobApplicationService service){this.service=service;}
 @GetMapping public List<JobApplication> all(@RequestParam(required=false) String q){return service.all(q);}
 @GetMapping("/{id}") public JobApplication get(@PathVariable Long id){return service.get(id);}
 @PostMapping public ResponseEntity<JobApplication> create(@RequestBody JobApplication a){return ResponseEntity.status(HttpStatus.CREATED).body(service.save(a));}
 @PutMapping("/{id}") public JobApplication update(@PathVariable Long id,@RequestBody JobApplication a){a.setId(id); return service.save(a);}
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){service.delete(id);return ResponseEntity.noContent().build();}
 @GetMapping("/dashboard") public DashboardDto dashboard(){return service.dashboard();}
}
