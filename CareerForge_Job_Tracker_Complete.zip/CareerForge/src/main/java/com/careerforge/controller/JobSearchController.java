package com.careerforge.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/jobs") public class JobSearchController {
 @GetMapping("/search") public List<Map<String,Object>> search(@RequestParam(defaultValue="Java Full Stack Developer") String q,@RequestParam(defaultValue="Bengaluru") String location){
  return List.of(
   job("CareerForge Demo","Java Full Stack Developer",location,"Remote/Hybrid","https://example.com/job/1",92,"demo"),
   job("TechNova","Spring Boot Developer",location,"Hybrid","https://example.com/job/2",88,"demo"),
   job("CloudWorks","Backend Java Engineer",location,"On-site","https://example.com/job/3",84,"demo")
  );
 }
 private Map<String,Object> job(String c,String t,String l,String mode,String url,int score,String source){return Map.of("company",c,"title",t,"location",l,"workMode",mode,"url",url,"matchScore",score,"source",source);}
}
