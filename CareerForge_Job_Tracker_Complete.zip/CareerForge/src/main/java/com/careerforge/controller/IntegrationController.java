package com.careerforge.controller;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/integrations") public class IntegrationController {
 @GetMapping public List<Map<String,Object>> integrations(){return List.of(
  Map.of("provider","LinkedIn","status","READY_FOR_OAUTH","supported","OAuth / approved API scopes","note","Requires LinkedIn-approved access for member/job/application data"),
  Map.of("provider","Naukri","status","IMPORT_REQUIRED","supported","CSV/JSON/email/extension adapter","note","Do not automate login or scrape protected pages"),
  Map.of("provider","Indeed","status","IMPORT_REQUIRED","supported","API/partner feed when available","note","Use an approved feed or import path")
 );}
}
