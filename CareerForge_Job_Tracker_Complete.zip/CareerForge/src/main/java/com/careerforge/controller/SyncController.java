package com.careerforge.controller;
import com.careerforge.model.SyncEvent; import com.careerforge.repository.SyncEventRepository; import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/sync") public class SyncController {
 private final SyncEventRepository repo; public SyncController(SyncEventRepository repo){this.repo=repo;}
 @PostMapping("/{provider}/event") public ResponseEntity<Map<String,Object>> event(@PathVariable String provider,@RequestBody Map<String,Object> body){
  SyncEvent e=new SyncEvent(); e.setProvider(provider); e.setExternalId(String.valueOf(body.getOrDefault("externalId",UUID.randomUUID()))); e.setEventType(String.valueOf(body.getOrDefault("eventType","APPLICATION_UPDATE"))); e.setStatus(String.valueOf(body.getOrDefault("status","RECEIVED"))); e.setPayload(body.toString()); repo.save(e); return ResponseEntity.accepted().body(Map.of("accepted",true,"provider",provider,"message","Connector event queued. Map this event to an application using the provider adapter."));
 }
 @GetMapping("/events") public List<SyncEvent> events(){return repo.findAll();}
}
