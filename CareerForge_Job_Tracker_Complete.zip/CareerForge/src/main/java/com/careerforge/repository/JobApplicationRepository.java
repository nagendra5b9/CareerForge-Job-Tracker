package com.careerforge.repository;
import com.careerforge.model.*; import org.springframework.data.jpa.repository.*; import org.springframework.data.repository.query.Param; import java.util.*;
public interface JobApplicationRepository extends JpaRepository<JobApplication,Long>{
 @Query("select a from JobApplication a where lower(a.company) like lower(concat('%',:q,'%')) or lower(a.jobTitle) like lower(concat('%',:q,'%')) or lower(coalesce(a.location,'')) like lower(concat('%',:q,'%'))") List<JobApplication> search(@Param("q") String q);
 long countByStatus(ApplicationStatus status);
}
