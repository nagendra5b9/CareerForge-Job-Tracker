package com.careerforge.repository;
import com.careerforge.model.SyncEvent; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface SyncEventRepository extends JpaRepository<SyncEvent,Long>{ Optional<SyncEvent> findTopByProviderAndExternalIdOrderByReceivedAtDesc(String provider,String externalId); }
