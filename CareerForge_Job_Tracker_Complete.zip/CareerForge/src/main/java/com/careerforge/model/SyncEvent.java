package com.careerforge.model;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity @Table(name="sync_events")
public class SyncEvent {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String provider; private String externalId; private String eventType; private String status; private LocalDateTime receivedAt;
 @Column(length=4000) private String payload;
 @PrePersist void init(){receivedAt=LocalDateTime.now();}
 public Long getId(){return id;} public String getProvider(){return provider;} public void setProvider(String v){provider=v;} public String getExternalId(){return externalId;} public void setExternalId(String v){externalId=v;} public String getEventType(){return eventType;} public void setEventType(String v){eventType=v;} public String getStatus(){return status;} public void setStatus(String v){status=v;} public LocalDateTime getReceivedAt(){return receivedAt;} public String getPayload(){return payload;} public void setPayload(String v){payload=v;}
}
