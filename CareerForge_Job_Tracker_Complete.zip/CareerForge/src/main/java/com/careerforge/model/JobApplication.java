package com.careerforge.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="job_applications", indexes={@Index(name="idx_company", columnList="company"), @Index(name="idx_status", columnList="status"), @Index(name="idx_applied_date", columnList="appliedDate")})
public class JobApplication {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false) private String company;
    @Column(nullable=false) private String jobTitle;
    private String location;
    private String source;
    private String jobUrl;
    private String employmentType;
    private String workMode;
    private String salary;
    private String resumeVersion;
    @Enumerated(EnumType.STRING) @Column(nullable=false) private ApplicationStatus status = ApplicationStatus.SAVED;
    private LocalDate appliedDate;
    private LocalDate deadline;
    private LocalDateTime nextActionAt;
    @Column(length=5000) private String notes;
    @Column(length=3000) private String jobDescription;
    private Integer matchScore;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist void created(){ createdAt=LocalDateTime.now(); updatedAt=createdAt; }
    @PreUpdate void updated(){ updatedAt=LocalDateTime.now(); }
    public Long getId(){return id;} public void setId(Long v){id=v;}
    public String getCompany(){return company;} public void setCompany(String v){company=v;}
    public String getJobTitle(){return jobTitle;} public void setJobTitle(String v){jobTitle=v;}
    public String getLocation(){return location;} public void setLocation(String v){location=v;}
    public String getSource(){return source;} public void setSource(String v){source=v;}
    public String getJobUrl(){return jobUrl;} public void setJobUrl(String v){jobUrl=v;}
    public String getEmploymentType(){return employmentType;} public void setEmploymentType(String v){employmentType=v;}
    public String getWorkMode(){return workMode;} public void setWorkMode(String v){workMode=v;}
    public String getSalary(){return salary;} public void setSalary(String v){salary=v;}
    public String getResumeVersion(){return resumeVersion;} public void setResumeVersion(String v){resumeVersion=v;}
    public ApplicationStatus getStatus(){return status;} public void setStatus(ApplicationStatus v){status=v;}
    public LocalDate getAppliedDate(){return appliedDate;} public void setAppliedDate(LocalDate v){appliedDate=v;}
    public LocalDate getDeadline(){return deadline;} public void setDeadline(LocalDate v){deadline=v;}
    public LocalDateTime getNextActionAt(){return nextActionAt;} public void setNextActionAt(LocalDateTime v){nextActionAt=v;}
    public String getNotes(){return notes;} public void setNotes(String v){notes=v;}
    public String getJobDescription(){return jobDescription;} public void setJobDescription(String v){jobDescription=v;}
    public Integer getMatchScore(){return matchScore;} public void setMatchScore(Integer v){matchScore=v;}
    public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
