package com.careerforge.model;
public enum ApplicationStatus { SAVED, APPLIED, SCREENING, ASSESSMENT, INTERVIEW, OFFER, REJECTED, WITHDRAWN }
