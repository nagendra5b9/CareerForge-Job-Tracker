package com.careerforge.service;
import com.careerforge.dto.DashboardDto; import com.careerforge.model.*; import com.careerforge.repository.*; import org.springframework.stereotype.Service; import java.util.*;
@Service public class JobApplicationService {
 private final JobApplicationRepository repo;
 public JobApplicationService(JobApplicationRepository repo){this.repo=repo;}
 public List<JobApplication> all(String q){return q==null||q.isBlank()?repo.findAll():repo.search(q.trim());}
 public JobApplication get(Long id){return repo.findById(id).orElseThrow(()->new NoSuchElementException("Application not found"));}
 public JobApplication save(JobApplication a){return repo.save(a);} public void delete(Long id){repo.deleteById(id);}
 public DashboardDto dashboard(){ long total=repo.count(), applied=repo.countByStatus(ApplicationStatus.APPLIED), screening=repo.countByStatus(ApplicationStatus.SCREENING), assessment=repo.countByStatus(ApplicationStatus.ASSESSMENT), interview=repo.countByStatus(ApplicationStatus.INTERVIEW), offers=repo.countByStatus(ApplicationStatus.OFFER), rejected=repo.countByStatus(ApplicationStatus.REJECTED), saved=repo.countByStatus(ApplicationStatus.SAVED); long responded=screening+assessment+interview+offers+rejected; int rate=applied==0?0:(int)Math.round(responded*100.0/applied); double avg=repo.findAll().stream().filter(x->x.getMatchScore()!=null).mapToInt(JobApplication::getMatchScore).average().orElse(0); return new DashboardDto(total,saved,applied,screening,assessment,interview,offers,rejected,rate,(int)Math.round(avg)); }
}
